package mk.ukim.finki.wp.labb.service.domain.impl;

import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.labb.model.domain.Accommodation;
import mk.ukim.finki.wp.labb.model.enums.State;
import mk.ukim.finki.wp.labb.model.exceptions.AccommodationNotFoundException;
import mk.ukim.finki.wp.labb.repository.AccommodationRepository;
import mk.ukim.finki.wp.labb.service.domain.AccommodationService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AccommodationServiceImpl implements AccommodationService {

    private final AccommodationRepository accommodationRepository;


    @Override
    public Accommodation findById(Long id) {
        Optional<Accommodation> optional = accommodationRepository.findById(id);

        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new AccommodationNotFoundException("Accommodation not found");
        }
    }

    @Override
    public Accommodation createAccommodation(Accommodation accommodation) {
        return accommodationRepository.save(accommodation);
    }

    @Override
    public Accommodation updateAccommodation(Long id, Accommodation accommodation) {
        Accommodation dbAccommodation = findById(id);

        if (accommodation.getName() != null) {
            dbAccommodation.setName(accommodation.getName());
        }

        if (accommodation.getCategory() != null) {
            dbAccommodation.setCategory(accommodation.getCategory());
        }

        if (accommodation.getState() != null) {
            dbAccommodation.setState(accommodation.getState());
        }

        if (accommodation.getHost() != null) {
            dbAccommodation.setHost(accommodation.getHost());
        }

        if (accommodation.getNumRooms() != null) {
            dbAccommodation.setNumRooms(accommodation.getNumRooms());
        }

        return accommodationRepository.save(dbAccommodation);
    }

    @Override
    public Accommodation deleteAccommodation(Long id) {
        Accommodation accommodation = findById(id);

        if (accommodation.getState().equals(State.BAD)) {
            accommodationRepository.deleteById(id);
            return accommodation;
        } else {
            throw new AccommodationNotFoundException("Accommodation is in good state");
        }
    }

    @Override
    public Accommodation makeUnavailableAccommodation(Long id) {
        Accommodation accommodation = findById(id);
        accommodation.setNumRooms(0);
        return accommodationRepository.save(accommodation);
    }
}
