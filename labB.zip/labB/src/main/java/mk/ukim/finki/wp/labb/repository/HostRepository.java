package mk.ukim.finki.wp.labb.repository;

import mk.ukim.finki.wp.labb.model.domain.Host;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HostRepository extends JpaRepository<Host, Long> {
}
