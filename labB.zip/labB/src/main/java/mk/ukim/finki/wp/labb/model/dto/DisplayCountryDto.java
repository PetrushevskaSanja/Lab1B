package mk.ukim.finki.wp.labb.model.dto;

public record DisplayCountryDto(String name, String continent) {
}
