package mk.ukim.finki.wp.labb.model.enums;

public enum State {
    GOOD, BAD
}
