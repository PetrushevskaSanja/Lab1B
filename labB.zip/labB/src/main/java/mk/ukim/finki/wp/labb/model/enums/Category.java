package mk.ukim.finki.wp.labb.model.enums;

public enum Category {
    ROOM, HOUSE, FLAT, APARTMENT, HOTEL, MOTEL
}
