package mk.ukim.finki.wp.labb.service.domain;

import mk.ukim.finki.wp.labb.model.domain.Host;

public interface HostService {
    Host findById(Long id);
}
