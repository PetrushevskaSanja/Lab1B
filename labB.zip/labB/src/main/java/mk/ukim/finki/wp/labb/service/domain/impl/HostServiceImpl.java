package mk.ukim.finki.wp.labb.service.domain.impl;

import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.labb.model.domain.Host;
import mk.ukim.finki.wp.labb.model.exceptions.HostNotFoundException;
import mk.ukim.finki.wp.labb.repository.HostRepository;
import mk.ukim.finki.wp.labb.service.domain.HostService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HostServiceImpl implements HostService {

    private final HostRepository hostRepository;

    @Override
    public Host findById(Long id) {
        Optional<Host> host = hostRepository.findById(id);

        if (host.isPresent()) {
            return host.get();
        } else {
            throw new HostNotFoundException("Host not found");
        }
    }
}
