package mk.ukim.finki.wp.labb.model.dto;

public record DisplayHostDto(String name, String surname, DisplayCountryDto country) {
}
