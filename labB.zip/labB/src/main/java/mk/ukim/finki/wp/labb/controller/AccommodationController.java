package mk.ukim.finki.wp.labb.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.labb.model.dto.CreateAccommodationDto;
import mk.ukim.finki.wp.labb.model.dto.DisplayAccommodationDto;
import mk.ukim.finki.wp.labb.service.application.AccommodationApplicationService;
import mk.ukim.finki.wp.labb.service.domain.AccommodationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class AccommodationController {

    private final AccommodationApplicationService accommodationApplicationService;

    @PostMapping("/")
    public ResponseEntity<DisplayAccommodationDto> createAccommodation(@Valid @RequestBody CreateAccommodationDto createAccommodationDto) {
        DisplayAccommodationDto dto = accommodationApplicationService.createAccommodation(createAccommodationDto);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DisplayAccommodationDto> updateAccommodation(@PathVariable Long id, @Valid @RequestBody CreateAccommodationDto createAccommodationDto) {
        DisplayAccommodationDto dto = accommodationApplicationService.updateAccommodation(id, createAccommodationDto);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<DisplayAccommodationDto> deleteAccommodation(@PathVariable Long id) {
        DisplayAccommodationDto dto = accommodationApplicationService.deleteAccommodation(id);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}/make-unavailable")
    public ResponseEntity<DisplayAccommodationDto> makeUnavailableAccommodation(@PathVariable Long id) {
        DisplayAccommodationDto dto = accommodationApplicationService.makeUnavailableAccommodation(id);
        return ResponseEntity.ok(dto);
    }
}
