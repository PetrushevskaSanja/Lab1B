package mk.ukim.finki.wp.labb.model.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "hosts")
@Data
@NoArgsConstructor
public class Host extends BaseAuditableEntity{

    private String name;

    private String surname;

    @ManyToOne(fetch = FetchType.LAZY)
    private Country country;
}
