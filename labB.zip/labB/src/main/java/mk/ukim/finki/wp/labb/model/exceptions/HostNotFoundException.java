package mk.ukim.finki.wp.labb.model.exceptions;

public class HostNotFoundException extends RuntimeException {
    public HostNotFoundException(String message) {
        super(message);
    }
}
